# Tinder
Tinder Swag

# Demo 
https://www.youtube.com/watch?v=FTGa8Tjwfi8

# Launch Tinder
- Clone
- Npm install in terminal
- Run on IOS simulator or Android emulator
